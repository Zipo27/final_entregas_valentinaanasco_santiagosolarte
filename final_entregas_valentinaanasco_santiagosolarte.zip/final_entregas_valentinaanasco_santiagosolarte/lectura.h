#ifndef LECTURA_H
#define LECTURA_H

/**
* @brief Lee una cadena de caracteres del teclado, incluyendo espacios
* @param max_tamano Cantidad maxima de caracteres a leer
* @return linea Linea leida
*/
char * leer_linea(int max_tamano);

/**
* @brief Lee una linea y saca de ella un numero entero
* @return Numero leido
*/
int leer_entero();

/**
* @brief Lee una linea y saca de ella un numero real
* @return Valor real leido
*/
float leer_real();

/**
* @brief Lee una linea y saca de ella un numero real doble
* @return Numero real de doble precision leido
*/
double leer_real_doble();

/**
* @brief Quita el caracter de fin de linea de una cadena
* @param linea Variable que almacena la cadena de caracteres
*/
void quitar_fin_de_linea(char * linea);

#endif
