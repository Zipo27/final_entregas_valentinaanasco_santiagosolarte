#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lectura.h"

char * leer_linea(int max_tamano){
	char * linea;
	
	//Reservar memoria para la linea
	linea = (char *)malloc(max_tamano);
	
	//Rellenar la linea con el caracter nulo \0
	memset(linea, 0, max_tamano);
	
	//Limpiar el resto de la salida
	fflush(stdin);
	
	//Leer la linea por teclado
	fgets(linea, max_tamano, stdin);
	
	//Quitar el caracter de ENTER "\n" al final de la linea
	quitar_fin_de_linea(linea);
	
	return linea;
}
	
int leer_entero(){
	int numero;
	char * linea;
	//Leer una linea
	linea = leer_linea(80);
	
	//Obtener un numero entero de la linea
	if (sscanf(linea, "%d", &numero) == 1) {
		return numero;
	}
	return 0;
}

float leer_real(){
	float numero;
	char * linea;
	//Leer una linea
	linea = leer_linea(80);
	
	//Obtener un numero real de la linea
	if (sscanf(linea, "%f", &numero) == 1) {
		return numero;
	}
	return 0;
}

double leer_real_doble(){
	double numero;
	char * linea;
	
	//Leer una linea
	linea = leer_linea(80);
	
	//Obtener un numero real de doble precision de la linea
	if (sscanf(linea, "%lf", &numero) == 1) {
		return numero;
	}
	return 0;
}

void quitar_fin_de_linea(char * linea){
	int len;
	
	//Calcular la longitud de la linea
	len = strlen(linea);
	
	//fgets lee y guarda el ENTER al final de la linea, es decir
	//en la ultima posicion de la cadena antes de nulo
	while (len > 0 && (linea[len - 1] == '\n' || linea[len - 1] == '\r')) {
		linea[--len] = 0;
	}
}
