#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "lectura.h"
#include "split.h"
#include "util.h"


#define MAXNOMBRE 256
#define MAXTELEFONO 32
#define MAXDIRECCION 256
#define MAXLINEA 1024

typedef struct{
	float x;
	float y;
}coordenada;

typedef struct{
	char nombres[MAXNOMBRE];
	char apellidos[MAXNOMBRE];
	char telefono[MAXTELEFONO];
	char direccion[MAXDIRECCION];
	float longitud;
	float latitud;
	int entregado;
}paquete;


paquete * leer_base_datos(char * ruta_archivo, int * n);
int buscar_mas_cercano(paquete* paquetes, int cantidad_paquetes, coordenada pos_actual_dron);

int main(int argc, char * argv[]) {
	
	char* base_datos; //Ruta del archivo csv
	paquete * paquetes; //Arreglo de paquetes
	int cantiad_paquetes = 0; //Cantidad de paquetes
	coordenada coord_incial_dron; //Posicion inicial del dron para x, y
	coordenada posicion_actual_dron; //Posicion actual del dron durante su recorrido 
	int cantidad_sin_entregar;
	
	//1. Leer el nombre del archivo
	printf("Ingrese la ruta de la base de datos: ");
	base_datos = leer_linea(MAXLINEA);
	
	//2. Crear el arreglo de estructuras y leer los datos
	paquetes = leer_base_datos(base_datos, &cantiad_paquetes);
	
	//Verificar si se leyeron paquetes
	if(cantiad_paquetes == 0){
		printf("No se encontraron datos v�lidos\n");
		return 0;
	}
	
	//printf("Cantiad de paquetes leidos: %d\n", cantiad_paquetes);
	
	//3. Leer la coordenada inicial del dron
	printf("Ingrese las coordenadas iniciales del dron: \n");
	printf("Coordenada para x: ");
	coord_incial_dron.x = leer_real();
	printf("Coordenada x: %.15f\n", coord_incial_dron.x);

	printf("Coordenada para y: ");
	coord_incial_dron.y = leer_real();
	printf("Coordenada y: %.15f\n", coord_incial_dron.y);
	
	//4. El dron comienza su recorrido en la posicion inicial igresada anteriormente
	posicion_actual_dron.x = coord_incial_dron.x;
	posicion_actual_dron.y = coord_incial_dron.y;
	
	//5. Todos los paquetes estan si entregar
	cantidad_sin_entregar = cantiad_paquetes;
	
	//6. Mientras exitan paquetes sin entregar el dron debera seguir haciendo su recorrido
	while(cantidad_sin_entregar != 0){
		
		//Buscar la posicion del paquete sin entregar mas cercano al dron 
		buscar_mas_cercano(paquetes, cantiad_paquetes, posicion_actual_dron);
		
		
		cantidad_sin_entregar--;
	}
	
	//Liberar la memoria reservada
	free(base_datos);
	//DESPUES DE LIBERAR LA MEMORIA NO DEBERIA
	//USARSE NINGUNA VARIABLE LIBERADA!!

	return 0;
}


float calcular_distancia(coordenada pos_actual_dron, paquete coord2){
	
	float distancia;
	
	// Formula de la distancia euclidiana
	distancia = sqrt(pow(coord2.longitud - pos_actual_dron.x, 2) + pow(coord2.latitud - pos_actual_dron.y, 2));
	
	return distancia;
}

int buscar_mas_cercano(paquete* paquetes, int cantidad_paquetes, coordenada pos_actual_dron){
	
	int pos_mas_cercana = 0;  // Inicializar con el primer �ndice
	float distancia_minima = calcular_distancia(pos_actual_dron, paquetes[0]);
	
	// Recorre el arreglo en busca de la posici�n m�s cercana a la posici�n del dron
	for(int i = 0; i <= cantidad_paquetes; i++){
		float distancia = calcular_distancia(pos_actual_dron, paquetes[i]);
		
		// Compara con la distancia m�nima encontrada hasta el momento
		if (distancia < distancia_minima){
			distancia_minima = distancia;
			pos_mas_cercana = i;
		}
	}
	
	printf("El paquete mas cercano se encuentra en la posicion: %d\n y tiene latitud: %.15f y longitud: %.15f", pos_mas_cercana, paquetes[pos_mas_cercana].latitud, paquetes[pos_mas_cercana].longitud);
	
	return pos_mas_cercana;
}

paquete * leer_base_datos(char * ruta_archivo, int * n) {
	
	FILE * fp;
	char linea[MAXLINEA];
	int total;
	split_list * lista;
	paquete * registros; //Registros de paquetes
	int i;
	
	//Abrir el archivo en modo Lectura: "r"
	fp = fopen(ruta_archivo, "r");
	//Si el arvhivo no se puedo abrir,
	//Imprimir un mensaje de error
	if(fp == NULL){
		printf("No se puedo abrir el archivo %s\n", ruta_archivo);
		return NULL;
	}
	
	total = 0;
	//Mientras no sea FIN DE ARCHIVO (end of file)
	while (!feof(fp)) {
		//Leer una linea del archivo
		fgets(linea, MAXLINEA, fp);
		//Quitar el fin de linea
		quitar_fin_de_linea(linea);
		
		//Dividir la linea leida usando delimitadores: ; y ENTER
		lista = split(linea, ";\r\n");
		//printf("Linea leida: %s Partes: %d\n", linea, lista->count);
		//Si la linea dividida tiene seis partes, contarla
		if(lista->count == 6){
			total++;
		}
	}
	
	//Crear el arreglo de paquetes
	if(total == 0){
		printf("No se econtraron registros v�lidos\n");
		return NULL;
	}
	//Reservar memoria para los paquetes
	registros = (paquete*)malloc(total * sizeof(paquete));
	
	//Rebobinar el apuntador del archivo
	fseek(fp, 0L, SEEK_SET);
	
	i = 0; //Posicion dentro del arreglo
	//Mientras no sea FIN DE ARCHIVO (end of file)
	while (!feof(fp)) {
		//Leer una linea del archivo
		fgets(linea, MAXLINEA, fp);
		//Quitar el fin de linea
		quitar_fin_de_linea(linea);
		
		//Dividir la linea leida usando delimitadores: ; y ENTER
		lista = split(linea, ";\r\n");
		//printf("Linea leida: %s Partes: %d\n", linea, lista->count);
		//Si la linea dividida tiene seis partes, contarla
		if(lista->count == 6){
			//Guardar los datos dentro del arreglo en la posicion i
			strcpy(registros[i].nombres, lista->parts[0]);
			strcpy(registros[i].apellidos, lista->parts[1]);
			strcpy(registros[i].telefono, lista->parts[2]);
			strcpy(registros[i].direccion, lista->parts[3]);
			registros[i].longitud = atof(lista->parts[4]);
			registros[i].latitud = atof(lista->parts[5]);
			i++;
		}
	}
	
	//Cerrar el archivo
	fclose(fp);
/*	for(int i = 0; i < total - 1; i++){*/
/*		printf("Posicion %d\n", i);*/
/*		printf("Nombre: %s\n", registros[i].nombres);*/
/*		printf("Apellidos: %s\n", registros[i].apellidos);*/
/*	    printf("Telefono: %s\n", registros[i].telefono);*/
/*		printf("Direccion: %s\n", registros[i].direccion);*/
/*		printf("Longitud: %.15f\n", registros[i].longitud);*/
/*		printf("Latitud: %.15f\n", registros[i].latitud);*/
/*	}*/
	printf("Total de lineas leidas: %d\n", total);
	
	*n = total - 1;
	
	return registros;
}
